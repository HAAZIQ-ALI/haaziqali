import { Routes, Route } from "wouter";
import Home from "@/pages/Home";
import NotFound from "@/pages/not-found";

export default function App() {
  return (
    <Routes>
      <Route path="/" component={Home} />
      <Route component={NotFound} />
    </Routes>
  );
}
