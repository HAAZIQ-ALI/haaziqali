import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Hero() {
  return (
    <section className="min-h-screen flex items-center pt-16">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="max-w-3xl"
        >
          <h1 className="text-4xl md:text-6xl font-bold mb-6">
            Hey, I'm{" "}
            <span className="bg-gradient-to-r from-primary to-blue-600 text-transparent bg-clip-text">
              Haaziq Ali
            </span>
          </h1>
          <p className="text-xl md:text-2xl text-muted-foreground mb-8">
            A 14-year-old programmer and aspiring AI engineer from Darbhanga,
            India. Passionate about coding, artificial intelligence, chess, and cooking.
          </p>
          <div className="flex gap-4">
            <Button size="lg" asChild>
              <a href="#projects">
                View Projects
                <ArrowRight className="ml-2 h-4 w-4" />
              </a>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <a href="#contact">Get in Touch</a>
            </Button>
          </div>
        </motion.div>
      </div>
    </section>
  );
}