import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Brain, Code, Gamepad2 } from "lucide-react";

const journeySteps = [
  {
    icon: Brain,
    title: "AI & Machine Learning",
    description: "Exploring artificial intelligence through hands-on projects",
  },
  {
    icon: Code,
    title: "Problem Solving",
    description: "Strengthening algorithmic skills on LeetCode",
  },
  {
    icon: Gamepad2,
    title: "Game Development",
    description: "Planning to explore Pygame for future game projects",
  },
];

export default function Journey() {
  return (
    <section id="journey" className="py-20">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl font-bold mb-4">Learning Journey</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            My ongoing path of growth and development in technology
          </p>
        </motion.div>

        <div className="relative max-w-3xl mx-auto">
          <div className="absolute left-1/2 transform -translate-x-1/2 h-full w-0.5 bg-border" />

          {journeySteps.map((step, index) => (
            <motion.div
              key={step.title}
              initial={{ opacity: 0, x: index % 2 === 0 ? -20 : 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: index * 0.2 }}
              viewport={{ once: true }}
              className={`relative mb-8 ${
                index % 2 === 0 ? "pr-8 md:ml-auto md:pl-8" : "pl-8"
              } md:w-1/2`}
            >
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="p-2 rounded-full bg-primary/10">
                      <step.icon className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="font-semibold">{step.title}</h3>
                  </div>
                  <p className="text-muted-foreground">{step.description}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
