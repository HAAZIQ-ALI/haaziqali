# Portfolio Website - Frontend Deployment Guide

## Overview
A static portfolio website built with React, TypeScript, and modern UI components. This is a frontend-only application that showcases your skills, projects, and journey.

## Quick Start with ZIP Download

1. **Download and Extract**
   - Download the ZIP file
   - Extract it to your desired location
   - The project structure should look like this:
   ```
   portfolio/
   ├── src/
   │   ├── components/
   │   ├── lib/
   │   └── pages/
   ├── public/
   ├── index.html
   ├── package.json
   └── vercel.json
   ```

2. **Local Development**
   ```bash
   # Install dependencies
   npm install

   # Start development server
   npm run dev

   # Your site will be running at http://localhost:5000
   ```

## Deploying to Vercel

1. **Prepare for Deployment**
   - Create a [Vercel account](https://vercel.com/signup) if you don't have one
   - Create a [GitHub account](https://github.com/signup) if you don't have one

2. **Deploy via Vercel Dashboard**
   - Go to [Vercel Dashboard](https://vercel.com/dashboard)
   - Click "New Project"
   - Choose "Upload" and select your project folder
   - Configure the project:
     - Framework Preset: Vite
     - Root Directory: `./`
     - Build Command: `npm run build`
     - Output Directory: `dist`
   - Click "Deploy"

3. **After Deployment**
   - Your site will be available at `https://<project-name>.vercel.app`
   - Set up a custom domain in Vercel dashboard if needed

## Project Structure
```
├── client/           # Frontend React application
│   ├── src/
│   │   ├── components/
│   │   ├── lib/
│   │   └── pages/
│   └── index.html
└── vercel.json       # Vercel configuration
```

## Project Features
- 🎨 Modern UI with Tailwind CSS
- 🔄 Smooth animations with Framer Motion
- 📱 Fully responsive design
- ⚡ Fast page loads with Vite
- 🎯 TypeScript for better development experience

## Customization
1. Update the content in `src/components/sections/` to reflect your personal information
2. Modify the theme colors in `tailwind.config.js`
3. Add or remove sections as needed

## Need Help?
If you encounter any issues during deployment, check Vercel's deployment logs in the dashboard or refer to their [documentation](https://vercel.com/docs).