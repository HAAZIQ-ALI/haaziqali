import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tv, Book } from "lucide-react";

const interests = [
  {
    icon: Tv,
    title: "Favorite Anime",
    description: "Top picks:",
    items: [
      "One Piece",
      "Vinland Saga",
      "Bungou Stray Dogs",
      "Fairy Tail",
      "Black Clover"
    ]
  },
  {
    icon: Book,
    title: "Manga",
    description: "Currently reading:",
    items: ["The Fragrant Flowers Blooms with Dignity"]
  }
];

export default function Interests() {
  return (
    <section id="interests" className="py-20 bg-gradient-to-b from-muted/50 to-background">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl font-bold mb-4">Interests & Hobbies</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Beyond coding, here are some things I'm passionate about
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {interests.map((interest, index) => (
            <motion.div
              key={interest.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <Card className="h-full">
                <CardHeader>
                  <div className="mb-4">
                    <interest.icon className="h-8 w-8 text-primary" />
                  </div>
                  <CardTitle>{interest.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground mb-4">{interest.description}</p>
                  <div className="flex flex-col gap-2">
                    {interest.items.map((item) => (
                      <span
                        key={item}
                        className="px-3 py-1.5 bg-primary/10 text-primary rounded-md"
                      >
                        {item}
                      </span>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
